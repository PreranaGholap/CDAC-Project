package com.userFront.controller;

import java.security.Principal;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.userFront.dao.RoleDao;
import com.userFront.domain.PrimaryAccount;
import com.userFront.domain.SavingsAccount;
import com.userFront.domain.User;
import com.userFront.domain.security.Role;
import com.userFront.domain.security.UserRole;
import com.userFront.service.UserService;
import com.userFront.domain.Appointment;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private RoleDao roleDao;

	@RequestMapping("/")
	public String home() {
		return "redirect:/index";
	}

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String signup(Model model) {
		User user = new User();

		model.addAttribute("user", user);

		return "signup";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public String signupPost(@ModelAttribute("user") User user, Model model) {

		// if (userService.checkUserExists(user.getUsername(), user.getEmail())) {
		if (userService.checkEmailExists(user.getEmail())) {
			model.addAttribute("emailExists", true);
			// if (userService.checkEmailExists(user.getEmail())) {
			// model.addAttribute("emailExists", true);
			// } else if (userService.checkUsernameExists(user.getUsername())) {
			// model.addAttribute("usernameExists", true);
			// }

			return "signup";
		} else if (userService.checkUsernameExists(user.getUsername())) {
			model.addAttribute("usernameExists", true);
			return "signup";
		} else {
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.clear();
			Random rand = new Random();

			Role userdata = new Role();
			userdata.setName("user" + rand.nextInt());
			userdata.setRoleId(rand.nextInt());
			userRoles.add(new UserRole(user, userdata));
			userService.createUser(user, userRoles);

			return "redirect:/";
		}
	}

	@RequestMapping("/userFront")
	public String userFront(Principal principal, Model model) {
		User user = userService.findByUsername(principal.getName());
		PrimaryAccount primaryAccount = user.getPrimaryAccount();
		SavingsAccount savingsAccount = user.getSavingsAccount();
		List<Appointment> appointmentList = user.getAppointmentList();
		String app = "No Appointment scheduled";
		if ((appointmentList != null) && !appointmentList.isEmpty()) {
			if (appointmentList.get((appointmentList.size() - 1)).getUser().getUserId() == user.getUserId()) {
				if (appointmentList.get((appointmentList.size() - 1)).isConfirmed()) {
					app = "Appointment scheduled on date: "
							+ appointmentList.get((appointmentList.size() - 1)).getDate() + " at "
							+ appointmentList.get((appointmentList.size() - 1)).getLocation() + " is confirmed.";
				} else {
					app = "Appointment scheduled on date: "
							+ appointmentList.get((appointmentList.size() - 1)).getDate() + " at "
							+ appointmentList.get((appointmentList.size() - 1)).getLocation()
							+ " confirmation is pending.";
				}
			}
		}

		model.addAttribute("primaryAccount", primaryAccount);
		model.addAttribute("savingsAccount", savingsAccount);
		model.addAttribute("appointment", app);
		return "userFront";
	}
}
