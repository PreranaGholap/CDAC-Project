import { Component, OnInit } from '@angular/core';
import { LoginComponent } from 'app/login/login.component';
import {AppointmentService} from '../appointment.service';


@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {

  appointmentList: Object[];

	constructor(private appointmentService: AppointmentService) {
		this.getAppointmentList();
	}

	getAppointmentList() {
		console.log("getAppointmentList");
		this.appointmentService.getAppointmentList().subscribe(
			res => {
				console.log(res.text())
        		this.appointmentList = JSON.parse(JSON.parse(JSON.stringify(res))._body);
      		},
      		error => console.log(error)
		)
	}	

	confirmAppointment(id: number) {
  		this.appointmentService.confirmAppointment(id).subscribe();
  		location.reload();
  	}

ngOnInit() {}
}
